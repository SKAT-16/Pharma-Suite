<h1>How to setup</h1>
<ol>
  <li>Start xampp server with Apache and Mysql</li>
  <li>Run /pharma-suite/_database/setup_db.php to Create the Database and the Tables</li>
  <li>Run /pharma-suite/_database/setup_mock_data.php to Create some data for logging in and working with the inventory</li>
  <li>Go to /pharma-suite which is the landing page</li>
</ol>

<h3>Hosted on Infinityfree</h3>
<p>Link: <a href="http://pharmacy-inventory.free.nf/pharma-suite/">Pharma-Suite</a></p>
